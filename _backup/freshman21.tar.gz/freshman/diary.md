---
published: false
layout: page
title: Diary
permalink: /diary/
---

网站创建时间：2011.07.19


2012.02.27 [模型融合](http://www.slideshare.net/xlvector/how-to-do-model-ensemble "How to do Model Ensemble")、诺基亚


2012.02.28 无聊[当代](http://www.google.com.hk/search?hl=zh-CN&amp;newwindow=1&amp;safe=strict&amp;client=firefox-a&amp;hs=yV4&amp;rls=org.mozilla%3Azh-CN%3Aunofficial&amp;biw=1680&amp;bih=881&amp;q=%E4%B8%AD%E5%9B%BD%E9%A9%AC%E5%85%8B%E6%80%9D%E4%B8%BB%E4%B9%89%E4%B8%8E%E5%BD%93%E4%BB%A3&amp;oq=%E4%B8%AD%E5%9B%BD%E9%A9%AC%E5%85%8B%E6%80%9D%E4%B8%BB%E4%B9%89%E4%B8%8E%E5%BD%93%E4%BB%A3&amp;aq=f&amp;aqi=&amp;aql=&amp;gs_sm=3&amp;gs_upl=8161l8161l0l8512l1l1l0l0l0l0l65l65l1l1l0&amp;gs_l=serp.3...8161l8161l0l8512l1l1l0l0l0l0l65l65l1l1l0 "中国马克思主义与当代")


2012.02.29 博弈


2012.03


KDD [雨夹雪](http://weather.news.sina.com.cn/news/2012/0302/73005.html "雨夹雪") [Lie to Me](http://en.wikipedia.org/wiki/Lie_to_Me "Lie to Me") [call SNPs](http://ged.msu.edu/angus/tutorials-2011/snp_tutorial.html "Calling SNPs with Samtools") 思路全错 当代PPT 博弈论 梦魇 Git 逛街 博客 拖延症 耳赤 延期 没正事 transifex 忘记 雪 作业 排球 诚心故意 RandomForest 吃货 朝令夕改 MATLAB 计算差 偶遇 生信 逃课 观点 7


2012.04


作文 糖 荒废 累 presentation 模型融合 [玉渊潭](http://yulijia.github.com/cn/%E6%B8%B8%E7%8E%A9%E6%8C%87%E5%8D%97/2012/04/15/Yuyuantan-Park.html "玉渊潭赏花") 情商低 照片 下雨 乒乓球 音乐会 热 vcfutils 时间紧 生与死 无语 雷雨 大量 春雨 饭卡 盖茨 复习 扰民 踩 卫生 失而复得 无趣 困 玩


2012.05


雍孔国 项目 颓废 注意力 立夏 熬夜 非参 篮球 合影 观天象 雷雨 三国杀 Ppp 拖延 大挑战 正负链 pm2.5 极讨厌 概率图 没去 智商低 肿瘤 硬盘 酸奶 谈话 乐扣 bite 口语 饭雨 [dream1](http://www.stanford.edu/group/wonglab/ "Wong Lab")


2012.06


组会 赶作业 基因技术 生物信息 太简单 教学差 自习 空调 解放 鸟巢 礼堂 千人课 读题 点名 login 车门 困 RepeatMasker 湿度 JS E.S.Lander 房子 白发 PSP type-0 租房 中介 [Nash](http://web.math.princeton.edu/jfnj/ "John F. Nash, Jr.") 签合同 夏游


2012.07


借钱 回家 崩溃 策划 整理 座谈 收拾 再见 第一天 怀念 卧谈 podcast 做饭 头发 向日葵 车票 修跳闸 永久性脑损伤 神侃 爬虫 仔细看/暴雨 会思考 恶心 Napoleon 走了 无缘参会 悠闲 冰棍 找茬 放假 雨落


2012.08


奥运 道理 假期 南瓜饼 回家 歇着 火车 领导 黑龙江 南山 到家 回归 [舍入](http://www.diycalculator.com/sp-round.shtml "舍入方法") 红肠 [by](https://nsaunders.wordpress.com/2010/08/20/a-brief-introduction-to-apply-in-r/ "A brief introduction to “apply” in R") permutation 加油 小聚 棒球 煮蛋器 折纸 z-score [$/](http://supersnail.com/os6/perley.txt "$/ is the input record separator") 还有问题 回家 perl 打杂 I/O RankProducts 宿舍 违约


2012.09


看房 转租 邮件 钥匙 weibo 搬家 热水器 磨蹭 写稿 PPT 改时间 师弟 [超几何检验](http://ygc.name/2012/04/28/enrichment-analysis/ "超几何检验") histone 午饭 值日 FDR 目标 genome-browser chown-apache:apache k-mer 吃鱼 权限 ucsc 讥笑 yulijia.github.com 伸手党 学R 没戏了 悲剧日 中秋


2012.10


矛盾 油漆 饭卡 鲁邦 修电梯 鸭脖 海报 rm 车票 入乡随俗 六度空间 查文献 rep 数分 金鸡湖 BingRen Lucy cohesin 志愿者 chinglish 秋雨 孙博 开会收获 背单词 出错 组内聚餐 回家 不准时 作息 推倒重来 死不认帐 


2012.11


normalize 暂停 没带伞 下雪 整理硬盘 数据线 工作时间 元太 回到8月 秋雨 晚秋 感冒 吃药 /etc/profile 借伞 [It all returns to nothing] 建站 理解 驼背 老师范儿 背地 翻墙 CLIP 晚睡 黑暗森林 编程 没组会 报名 科研暴发户 欺软怕硬 


2012.12


倒计时 饭卡 海峡两岸 [施一公](http://blog.sciencenet.cn/home.php?mod=space&uid=46212&do=blog&id=486270 "如何做一名优秀的博士生：（二）方法论的转变") -8度 超转折 二层 没意思邮件 饭卡 开始迁移 打包 下雪搬家 甲醛 恶心食堂 开题 大地餐厅 形式主义 没法提交 ppt 占用内存 饺子 类不均衡 [d3js](http://d3js.org/ "可视化+js") 讨论课 0base 聚餐 奋发 放弃 四叶 新的开始


2013.01


K歌 流泪 14人 开始 服务器 初中数学 LDA 缓行 6/8 7/8 8/8 分析bucter 肩膀 无法网购 结束了 毕业论文 rosalind.info 八卦 aggregate 加油 看paper 清华医学院 GFW 布置 捣蛋组合 难念的经 公交车 努力 北邮 太痔 空气 


2013.02


卧铺 带饭 大雪 两顿 微波炉 loser 回来了 休息 过年 小陀螺 实验室 悲痛 伤 红领巾 不照相 服务器 八宝饭 饺子 回来 工作 烤肉 计算 结果好 出错 纠结 谈话 25 准备


2013.03

\[1 2 3 4 转考\] 无眠 看你 情绪 8级大风 害怕 活检 春雨 101 口语 人口模型 熬夜 家 ma 放轻松 回家 忙下一阵 邮件 animation makefile rebase 没读 漫画 口音 62% 马力全开 egg

2013.04

愚人节 清明 H7N9 SVD 复印5张 Code
