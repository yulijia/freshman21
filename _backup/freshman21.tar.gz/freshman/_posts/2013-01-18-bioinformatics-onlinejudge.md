--- 
published: true
title: rosalind.info——一个在线生物信息学算法学习网站
layout: post
author: Yu
category: 知行并进
tags: 
- rosalind.info
- Bioinformatics

---
最近发现了一个网站，有点类似Project Euler 和算法onlinejudge的生物信息学学算法学习网站rosalind.info。从最简单的DNA核苷酸含量计算开始，有100多道生物信息学在线问题可以挑战。

这个Project名字（rosalind）是纪念拍摄DNA晶体衍射图片的[Rosalind Elsie Franklin](http://en.wikipedia.org/wiki/Rosalind_Franklin)（没得到诺奖，早逝。*另外这个衍射图片怎么能看出双螺旋来，我一直没弄明白，请教生物专业的同学，他们也不清楚*）。

里面的题目还算有趣，我从头开始做了10道，题目都不难，当然自己的程序离完美解答还有差距。

有了里面的题目，我的Howto系列又可以开始写了<code>:)</code>


