---
layout: page
title: About
comments: yes
permalink: /about/
---

<img title="麋鹿" src="https://i.imgur.com/15BT1.jpg" alt="麋鹿" width="580" height="668" />

### Hi, this is Lijia Yu.

